import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  ManyToMany,
  JoinTable,
  OneToMany,
} from 'typeorm';
import { Role } from '../../roles/entities/role.entity';
import { Permission } from '../../permissions/entities/permission.entity';
import { Order } from '../../orders/entities/order.entity';

/**
 * The User entity represents an account that can log into the system.  It
 * holds the user's credentials and relational links to roles and
 * permissions.  Storing the password requires hashing; never persist
 * plain text passwords in production.  Roles and permissions are
 * resolved via many-to-many relations.
 */
@Entity()
export class User {
  @PrimaryGeneratedColumn('uuid')
  id!: string;

  @Column({ unique: true })
  email!: string;

  @Column()
  password!: string;

  @Column()
  name!: string;

  // A user can have many roles.  Roles are stored in a separate table.
  @ManyToMany(() => Role, (role) => role.users, { cascade: true })
  @JoinTable({ name: 'user_roles' })
  roles!: Role[];

  // Permissions can be granted directly to a user in addition to roles.
  @ManyToMany(() => Permission, (permission) => permission.users, {
    cascade: true,
  })
  @JoinTable({ name: 'user_permissions' })
  permissions!: Permission[];

  // A user can create many orders (e.g. sales representative).
  @OneToMany(() => Order, (order) => order.user)
  orders!: Order[];
}