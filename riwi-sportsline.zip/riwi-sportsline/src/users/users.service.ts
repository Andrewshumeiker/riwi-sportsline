import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { User } from './entities/user.entity';
import { CreateUserDto } from './dto/create-user.dto';
import { UpdateUserDto } from './dto/update-user.dto';
import { Role } from '../roles/entities/role.entity';
import { Permission } from '../permissions/entities/permission.entity';
import * as bcrypt from 'bcrypt';

/**
 * Service providing CRUD operations for users.  It also handles
 * password hashing and assignment of roles and permissions.  By
 * abstracting these concerns into a service we make the controller
 * thin and reusable throughout the application.
 */
@Injectable()
export class UsersService {
  constructor(
    @InjectRepository(User) private readonly userRepository: Repository<User>,
    @InjectRepository(Role) private readonly roleRepository: Repository<Role>,
    @InjectRepository(Permission) private readonly permissionRepository: Repository<Permission>,
  ) {}

  async findAll(): Promise<User[]> {
    return this.userRepository.find({ relations: ['roles', 'permissions'] });
  }

  async findOne(id: string): Promise<User> {
    const user = await this.userRepository.findOne({ where: { id }, relations: ['roles', 'permissions'] });
    if (!user) {
      throw new NotFoundException(`User with id ${id} not found`);
    }
    return user;
  }

  async findByEmail(email: string): Promise<User | null> {
    return this.userRepository.findOne({ where: { email }, relations: ['roles', 'permissions'] });
  }

  async create(createDto: CreateUserDto): Promise<User> {
    const hashed = await bcrypt.hash(createDto.password, 10);
    const user = this.userRepository.create({
      name: createDto.name,
      email: createDto.email,
      password: hashed,
    });
    // Assign roles if provided
    if (createDto.roleIds && createDto.roleIds.length > 0) {
      user.roles = await this.roleRepository.findByIds(createDto.roleIds);
    }
    // Assign permissions if provided
    if (createDto.permissionIds && createDto.permissionIds.length > 0) {
      user.permissions = await this.permissionRepository.findByIds(
        createDto.permissionIds,
      );
    }
    return this.userRepository.save(user);
  }

  async update(id: string, updateDto: UpdateUserDto): Promise<User> {
    const user = await this.findOne(id);
    // Only update fields that are provided
    if (updateDto.name) user.name = updateDto.name;
    if (updateDto.email) user.email = updateDto.email;
    if (updateDto.password) {
      user.password = await bcrypt.hash(updateDto.password, 10);
    }
    if (updateDto.roleIds) {
      user.roles = await this.roleRepository.findByIds(updateDto.roleIds);
    }
    if (updateDto.permissionIds) {
      user.permissions = await this.permissionRepository.findByIds(
        updateDto.permissionIds,
      );
    }
    return this.userRepository.save(user);
  }

  async remove(id: string): Promise<void> {
    const user = await this.findOne(id);
    await this.userRepository.remove(user);
  }
}