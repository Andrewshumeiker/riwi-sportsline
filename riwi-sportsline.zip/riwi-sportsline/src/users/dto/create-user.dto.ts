import { IsString, IsEmail, IsNotEmpty, MinLength, IsOptional, IsArray, ArrayUnique } from 'class-validator';

/**
 * DTO for creating a new user.  It validates the incoming payload
 * ensuring that required fields are provided and optional arrays are
 * unique.  Passwords are validated for minimum length.  Role and
 * permission identifiers are optional to allow creating a user
 * without any assignments.
 */
export class CreateUserDto {
  @IsString()
  @IsNotEmpty()
  name!: string;

  @IsEmail()
  email!: string;

  @IsString()
  @MinLength(6)
  password!: string;

  @IsOptional()
  @IsArray()
  @ArrayUnique()
  roleIds?: string[];

  @IsOptional()
  @IsArray()
  @ArrayUnique()
  permissionIds?: string[];
}