import { PartialType } from '@nestjs/mapped-types';
import { CreateUserDto } from './create-user.dto';

/**
 * DTO for updating a user.  It extends CreateUserDto but makes all
 * properties optional.  This allows partial updates via PATCH or PUT
 * operations where only the fields provided in the request body
 * will be changed.
 */
export class UpdateUserDto extends PartialType(CreateUserDto) {}