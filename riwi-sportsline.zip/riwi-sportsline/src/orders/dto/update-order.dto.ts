import { PartialType } from '@nestjs/mapped-types';
import { CreateOrderDto } from './create-order.dto';

/**
 * DTO for updating an order.  Allows optional updates to the
 * associated client, products, and user.  Changing the set of
 * products triggers recalculation of the total in the service.
 */
export class UpdateOrderDto extends PartialType(CreateOrderDto) {}