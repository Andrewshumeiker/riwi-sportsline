import { IsString, IsNotEmpty, IsArray, ArrayNotEmpty, ArrayUnique } from 'class-validator';

/**
 * DTO for creating an order.  Requires a client identifier and an array
 * of product identifiers.  The user identifier can be derived from
 * authentication context but is accepted here for demonstration.
 */
export class CreateOrderDto {
  @IsString()
  @IsNotEmpty()
  clientId!: string;

  @IsString()
  @IsNotEmpty()
  userId!: string;

  @IsArray()
  @ArrayNotEmpty()
  @ArrayUnique()
  productIds!: string[];
}