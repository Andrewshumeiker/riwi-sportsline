import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Order } from './entities/order.entity';
import { Client } from '../clients/entities/client.entity';
import { Product } from '../products/entities/product.entity';
import { User } from '../users/entities/user.entity';
import { OrdersService } from './orders.service';
import { OrdersController } from './orders.controller';
import { RolesGuard } from '../common/guards/roles.guard';
import { PermissionsGuard } from '../common/guards/permissions.guard';

@Module({
  imports: [TypeOrmModule.forFeature([Order, Client, Product, User])],
  providers: [OrdersService, RolesGuard, PermissionsGuard],
  controllers: [OrdersController],
  exports: [OrdersService],
})
export class OrdersModule {}