import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Order } from './entities/order.entity';
import { CreateOrderDto } from './dto/create-order.dto';
import { UpdateOrderDto } from './dto/update-order.dto';
import { Client } from '../clients/entities/client.entity';
import { Product } from '../products/entities/product.entity';
import { User } from '../users/entities/user.entity';

@Injectable()
export class OrdersService {
  constructor(
    @InjectRepository(Order)
    private readonly orderRepository: Repository<Order>,
    @InjectRepository(Client)
    private readonly clientRepository: Repository<Client>,
    @InjectRepository(Product)
    private readonly productRepository: Repository<Product>,
    @InjectRepository(User)
    private readonly userRepository: Repository<User>,
  ) {}

  findAll(): Promise<Order[]> {
    return this.orderRepository.find({ relations: ['client', 'user', 'products'] });
  }

  async findOne(id: string): Promise<Order> {
    const order = await this.orderRepository.findOne({ where: { id }, relations: ['client', 'user', 'products'] });
    if (!order) {
      throw new NotFoundException(`Order with id ${id} not found`);
    }
    return order;
  }

  /**
   * Create a new order.  It looks up the client, user and products
   * referenced in the DTO.  The total is computed by summing the
   * product prices.  If any entity is not found a NotFoundException
   * will be thrown.
   */
  async create(dto: CreateOrderDto): Promise<Order> {
    const client = await this.clientRepository.findOne({ where: { id: dto.clientId } });
    if (!client) throw new NotFoundException('Client not found');
    const user = await this.userRepository.findOne({ where: { id: dto.userId } });
    if (!user) throw new NotFoundException('User not found');
    const products = await this.productRepository.findByIds(dto.productIds);
    if (products.length !== dto.productIds.length) {
      throw new NotFoundException('One or more products not found');
    }
    const total = products.reduce((sum, p) => sum + Number(p.price), 0);
    const order = this.orderRepository.create({
      client,
      user,
      products,
      total,
    });
    return this.orderRepository.save(order);
  }

  /**
   * Update an existing order.  When products are updated the total
   * will be recalculated.  Missing entities cause a NotFoundException.
   */
  async update(id: string, dto: UpdateOrderDto): Promise<Order> {
    const order = await this.findOne(id);
    if (dto.clientId) {
      const client = await this.clientRepository.findOne({ where: { id: dto.clientId } });
      if (!client) throw new NotFoundException('Client not found');
      order.client = client;
    }
    if (dto.userId) {
      const user = await this.userRepository.findOne({ where: { id: dto.userId } });
      if (!user) throw new NotFoundException('User not found');
      order.user = user;
    }
    if (dto.productIds) {
      const products = await this.productRepository.findByIds(dto.productIds);
      if (products.length !== dto.productIds.length) {
        throw new NotFoundException('One or more products not found');
      }
      order.products = products;
      order.total = products.reduce((sum, p) => sum + Number(p.price), 0);
    }
    return this.orderRepository.save(order);
  }

  async remove(id: string): Promise<void> {
    const order = await this.findOne(id);
    await this.orderRepository.remove(order);
  }
}