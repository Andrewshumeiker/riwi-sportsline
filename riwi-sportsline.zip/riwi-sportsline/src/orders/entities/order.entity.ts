import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  ManyToOne,
  ManyToMany,
  JoinTable,
} from 'typeorm';
import { Client } from '../../clients/entities/client.entity';
import { Product } from '../../products/entities/product.entity';
import { User } from '../../users/entities/user.entity';

/**
 * The Order entity represents a purchase made by a client.  It links
 * to the client who placed the order, the user who processed it,
 * and the products contained within.  The total is stored to
 * simplify reporting but can be derived by summing product prices.
 */
@Entity()
export class Order {
  @PrimaryGeneratedColumn('uuid')
  id!: string;

  @Column({ type: 'timestamp', default: () => 'CURRENT_TIMESTAMP' })
  date!: Date;

  @Column('decimal', { precision: 10, scale: 2 })
  total!: number;

  @ManyToOne(() => Client, (client) => client.orders, { eager: true })
  client!: Client;

  @ManyToOne(() => User, (user) => user.orders, { eager: true })
  user!: User;

  @ManyToMany(() => Product, (product) => product.orders, { eager: true })
  @JoinTable({ name: 'order_products' })
  products!: Product[];
}