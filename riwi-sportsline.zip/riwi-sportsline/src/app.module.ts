import { Module } from '@nestjs/common';
import { ConfigModule, ConfigService } from '@nestjs/config';
import { TypeOrmModule } from '@nestjs/typeorm';

import configuration from './config/configuration';
import { validationSchema } from './config/validation';

// Import feature modules
import { UsersModule } from './users/users.module';
import { ProductsModule } from './products/products.module';
import { ClientsModule } from './clients/clients.module';
import { OrdersModule } from './orders/orders.module';
import { RolesModule } from './roles/roles.module';
import { PermissionsModule } from './permissions/permissions.module';
import { AuthModule } from './auth/auth.module';
import { ApiKeyModule } from './api-key/api-key.module';

@Module({
  imports: [
    // Load environment variables and validate them
    ConfigModule.forRoot({
      isGlobal: true,
      load: [configuration],
      validationSchema,
    }),
    // Configure TypeORM asynchronously using ConfigService
    TypeOrmModule.forRootAsync({
      imports: [ConfigModule],
      inject: [ConfigService],
      useFactory: (config: ConfigService) => ({
        type: 'postgres',
        host: config.get<string>('database.host'),
        port: config.get<number>('database.port'),
        username: config.get<string>('database.user'),
        password: config.get<string>('database.password'),
        database: config.get<string>('database.name'),
        entities: [__dirname + '/**/*.entity{.ts,.js}'],
        synchronize: true, // NOTE: disable in production
      }),
    }),
    UsersModule,
    ProductsModule,
    ClientsModule,
    OrdersModule,
    RolesModule,
    PermissionsModule,
    AuthModule,
    ApiKeyModule,
  ],
})
export class AppModule {
  /**
   * Apply global middleware.  Here we register the LoggerMiddleware
   * for all routes.  More specific routes can be targeted by
   * modifying the consumer configuration.
   */
  configure(consumer: import('@nestjs/common').MiddlewareConsumer) {
    const { LoggerMiddleware } = require('./middleware/logger.middleware');
    consumer.apply(LoggerMiddleware).forRoutes('*');
  }
}