import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  ManyToMany,
} from 'typeorm';
import { User } from '../../users/entities/user.entity';
import { Role } from '../../roles/entities/role.entity';

/**
 * A permission represents a fine‑grained capability that can be
 * assigned to roles or directly to users.  Examples include
 * "create-product", "update-order", or "view-clients".
 */
@Entity()
export class Permission {
  @PrimaryGeneratedColumn('uuid')
  id!: string;

  @Column({ unique: true })
  name!: string;

  @Column({ nullable: true })
  description?: string;

  @ManyToMany(() => User, (user) => user.permissions)
  users!: User[];

  @ManyToMany(() => Role, (role) => role.permissions)
  roles!: Role[];
}