import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Permission } from './entities/permission.entity';
import { PermissionsService } from './permissions.service';
import { PermissionsController } from './permissions.controller';
import { RolesGuard } from '../common/guards/roles.guard';
import { PermissionsGuard } from '../common/guards/permissions.guard';

@Module({
  imports: [TypeOrmModule.forFeature([Permission])],
  providers: [PermissionsService, RolesGuard, PermissionsGuard],
  controllers: [PermissionsController],
  exports: [PermissionsService],
})
export class PermissionsModule {}