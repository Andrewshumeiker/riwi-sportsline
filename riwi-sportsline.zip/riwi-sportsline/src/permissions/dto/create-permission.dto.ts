import { IsString, IsNotEmpty, IsOptional } from 'class-validator';

/**
 * DTO for creating a permission.  Defines a unique name and an
 * optional description.
 */
export class CreatePermissionDto {
  @IsString()
  @IsNotEmpty()
  name!: string;

  @IsOptional()
  @IsString()
  description?: string;
}