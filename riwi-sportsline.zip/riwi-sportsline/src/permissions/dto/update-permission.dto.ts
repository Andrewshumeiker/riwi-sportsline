import { PartialType } from '@nestjs/mapped-types';
import { CreatePermissionDto } from './create-permission.dto';

/**
 * DTO for updating a permission.  Makes all fields optional.
 */
export class UpdatePermissionDto extends PartialType(CreatePermissionDto) {}