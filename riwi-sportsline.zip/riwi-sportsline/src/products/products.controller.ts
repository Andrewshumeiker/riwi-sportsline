import {
  Controller,
  Get,
  Post,
  Put,
  Delete,
  Param,
  Body,
  UseGuards,
} from '@nestjs/common';
import { ProductsService } from './products.service';
import { CreateProductDto } from './dto/create-product.dto';
import { UpdateProductDto } from './dto/update-product.dto';
import { Roles } from '../common/decorators/roles.decorator';
import { Permissions } from '../common/decorators/permissions.decorator';
import { RolesGuard } from '../common/guards/roles.guard';
import { PermissionsGuard } from '../common/guards/permissions.guard';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';

/**
 * Controller exposing endpoints for products.  Read operations are
 * available to any authenticated user, while write operations require
 * administrative privileges or specific permissions.  Guards are
 * stacked to enforce these rules.
 */
@Controller('products')
@UseGuards(JwtAuthGuard, RolesGuard, PermissionsGuard)
export class ProductsController {
  constructor(private readonly productsService: ProductsService) {}

  /**
   * Retrieve all products.  Any authenticated user may access this
   * endpoint.
   */
  @Get()
  findAll() {
    return this.productsService.findAll();
  }

  /**
   * Retrieve a single product by ID.  Any authenticated user may
   * access this endpoint.
   */
  @Get(':id')
  findOne(@Param('id') id: string) {
    return this.productsService.findOne(id);
  }

  /**
   * Create a new product.  Requires the 'admin' role or the
   * 'create-product' permission.
   */
  @Post()
  @Roles('admin')
  @Permissions('create-product')
  create(@Body() createDto: CreateProductDto) {
    return this.productsService.create(createDto);
  }

  /**
   * Update an existing product.  Requires the 'admin' role or the
   * 'update-product' permission.
   */
  @Put(':id')
  @Roles('admin')
  @Permissions('update-product')
  update(@Param('id') id: string, @Body() updateDto: UpdateProductDto) {
    return this.productsService.update(id, updateDto);
  }

  /**
   * Delete a product.  Requires the 'admin' role or the
   * 'delete-product' permission.
   */
  @Delete(':id')
  @Roles('admin')
  @Permissions('delete-product')
  remove(@Param('id') id: string) {
    return this.productsService.remove(id);
  }
}