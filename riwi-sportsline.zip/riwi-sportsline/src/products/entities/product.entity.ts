import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  ManyToMany,
  JoinTable,
} from 'typeorm';
import { Order } from '../../orders/entities/order.entity';

/**
 * The Product entity represents an item available for purchase.  It
 * includes basic fields such as name, price and description.  The
 * many-to-many relationship with orders allows a product to belong
 * to multiple orders and vice versa.
 */
@Entity()
export class Product {
  @PrimaryGeneratedColumn('uuid')
  id!: string;

  @Column()
  name!: string;

  @Column('decimal', { precision: 10, scale: 2 })
  price!: number;

  @Column({ nullable: true })
  description?: string;

  @ManyToMany(() => Order, (order) => order.products)
  @JoinTable({ name: 'order_products' })
  orders!: Order[];
}