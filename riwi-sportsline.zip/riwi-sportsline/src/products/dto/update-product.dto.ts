import { PartialType } from '@nestjs/mapped-types';
import { CreateProductDto } from './create-product.dto';

/**
 * DTO for updating a product.  Inherits validation rules from
 * CreateProductDto but makes all fields optional.
 */
export class UpdateProductDto extends PartialType(CreateProductDto) {}