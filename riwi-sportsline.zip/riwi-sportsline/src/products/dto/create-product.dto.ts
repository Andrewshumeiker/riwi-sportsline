import { IsString, IsNotEmpty, IsNumber, Min, IsOptional } from 'class-validator';

/**
 * DTO for creating a product.  Ensures the name is provided and
 * price is a positive number.  Description is optional.
 */
export class CreateProductDto {
  @IsString()
  @IsNotEmpty()
  name!: string;

  @IsNumber()
  @Min(0)
  price!: number;

  @IsOptional()
  @IsString()
  description?: string;
}