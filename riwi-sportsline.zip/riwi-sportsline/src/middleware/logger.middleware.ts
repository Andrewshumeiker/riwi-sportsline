import { Injectable, NestMiddleware } from '@nestjs/common';
import { Request, Response, NextFunction } from 'express';

/**
 * Middleware that logs each incoming request method and URL.  It can
 * easily be extended to include request body, headers or other
 * information.  Register it in a module to apply globally or to
 * specific routes.
 */
@Injectable()
export class LoggerMiddleware implements NestMiddleware {
  use(req: Request, res: Response, next: NextFunction) {
    console.log(`Incoming request: ${req.method} ${req.originalUrl}`);
    next();
  }
}