import { IsString, IsNotEmpty, IsEmail } from 'class-validator';

/**
 * DTO for creating a client.  Validates basic fields.  In a full
 * implementation you may include additional fields such as address.
 */
export class CreateClientDto {
  @IsString()
  @IsNotEmpty()
  name!: string;

  @IsEmail()
  email!: string;
}