import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  OneToMany,
} from 'typeorm';
import { Order } from '../../orders/entities/order.entity';

/**
 * The Client entity stores customer information.  A client can have
 * multiple orders associated with them.  In a real application you
 * might include additional fields such as address or phone number.
 */
@Entity()
export class Client {
  @PrimaryGeneratedColumn('uuid')
  id!: string;

  @Column()
  name!: string;

  @Column({ unique: true })
  email!: string;

  @OneToMany(() => Order, (order) => order.client)
  orders!: Order[];
}