/**
 * This file centralizes configuration values loaded from environment variables.
 * It is consumed by the ConfigModule so that other modules can inject
 * ConfigService and retrieve strongly typed values.  Separating the
 * configuration allows us to take advantage of NestJS lazy loading
 * and keep environment concerns decoupled from business logic.
 */
export default () => ({
  port: parseInt(process.env.PORT as string, 10) || 3000,
  database: {
    host: process.env.DB_HOST || 'localhost',
    port: parseInt(process.env.DB_PORT as string, 10) || 5432,
    user: process.env.DB_USER || 'postgres',
    password: process.env.DB_PASSWORD || 'postgres',
    name: process.env.DB_NAME || 'riwi_sportsline',
  },
  jwt: {
    secret: process.env.JWT_SECRET || 'secret',
    expiration: process.env.JWT_EXPIRATION || '3600',
    refreshSecret: process.env.JWT_REFRESH_SECRET || 'refresh',
    refreshExpiration: process.env.JWT_REFRESH_EXPIRATION || '86400',
  },
  apiKey: {
    header: process.env.API_KEY_HEADER || 'x-api-key',
    keys: (process.env.API_KEYS || '').split(',').filter(Boolean),
  },
  oauth: {
    google: {
      clientId: process.env.GOOGLE_CLIENT_ID || '',
      clientSecret: process.env.GOOGLE_CLIENT_SECRET || '',
      callbackUrl: process.env.GOOGLE_CALLBACK_URL || '',
    },
  },
});