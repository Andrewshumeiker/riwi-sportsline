import * as Joi from 'joi';

/**
 * The validation schema is used by the ConfigModule to ensure that
 * required environment variables are present and have the correct
 * type.  Joi provides expressive validation rules and default values.
 */
export const validationSchema = Joi.object({
  PORT: Joi.number().default(3000),
  DB_HOST: Joi.string().required(),
  DB_PORT: Joi.number().default(5432),
  DB_USER: Joi.string().required(),
  DB_PASSWORD: Joi.string().required(),
  DB_NAME: Joi.string().required(),
  JWT_SECRET: Joi.string().required(),
  JWT_EXPIRATION: Joi.string().default('3600'),
  JWT_REFRESH_SECRET: Joi.string().required(),
  JWT_REFRESH_EXPIRATION: Joi.string().default('86400'),
  API_KEY_HEADER: Joi.string().default('x-api-key'),
  API_KEYS: Joi.string().allow(''),
  GOOGLE_CLIENT_ID: Joi.string().allow(''),
  GOOGLE_CLIENT_SECRET: Joi.string().allow(''),
  GOOGLE_CALLBACK_URL: Joi.string().allow(''),
});