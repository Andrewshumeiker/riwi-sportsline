import { Injectable, CanActivate, ExecutionContext, ForbiddenException } from '@nestjs/common';
import { Reflector } from '@nestjs/core';

/**
 * Guard that validates whether the authenticated user possesses the
 * required permissions.  If no permissions are defined on the route
 * then access is granted.  The user object is expected to contain
 * a `permissions` array populated by the authentication module.
 */
@Injectable()
export class PermissionsGuard implements CanActivate {
  constructor(private readonly reflector: Reflector) {}

  canActivate(context: ExecutionContext): boolean {
    const requiredPermissions = this.reflector.getAllAndOverride<string[]>(
      'permissions',
      [context.getHandler(), context.getClass()],
    );
    if (!requiredPermissions || requiredPermissions.length === 0) {
      return true;
    }
    const request = context.switchToHttp().getRequest();
    const user = request.user;
    if (!user || !Array.isArray(user.permissions)) {
      throw new ForbiddenException('Missing permissions for user');
    }
    const hasPermission = user.permissions.some((perm: string) =>
      requiredPermissions.includes(perm),
    );
    if (!hasPermission) {
      throw new ForbiddenException('Insufficient permissions');
    }
    return true;
  }
}