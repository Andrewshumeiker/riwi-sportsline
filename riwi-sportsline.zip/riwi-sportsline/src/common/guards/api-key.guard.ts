import { CanActivate, ExecutionContext, Injectable, UnauthorizedException } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';

/**
 * A simple guard that checks for a valid API key in the request headers.
 * Valid keys are defined via environment variables.  For a production
 * system you would store keys in a database and implement rotation.
 */
@Injectable()
export class ApiKeyGuard implements CanActivate {
  constructor(private readonly configService: ConfigService) {}

  canActivate(context: ExecutionContext): boolean {
    const request = context.switchToHttp().getRequest();
    const headerName = this.configService.get<string>('apiKey.header');
    const apiKey = request.headers[headerName.toLowerCase()];
    const validKeys = this.configService.get<string[]>('apiKey.keys');
    if (!apiKey || !validKeys || !validKeys.includes(apiKey)) {
      throw new UnauthorizedException('Invalid API key');
    }
    return true;
  }
}