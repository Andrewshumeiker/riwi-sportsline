import { SetMetadata } from '@nestjs/common';

/**
 * Decorator to mark an endpoint with the permissions required for access.
 * The PermissionsGuard will enforce these at runtime.
 */
export const Permissions = (...permissions: string[]) =>
  SetMetadata('permissions', permissions);