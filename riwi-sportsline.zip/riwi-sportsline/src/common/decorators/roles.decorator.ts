import { SetMetadata } from '@nestjs/common';

/**
 * Custom decorator to mark an endpoint with the roles required for access.
 * The RolesGuard will read this metadata and enforce it at runtime.
 *
 * Usage:
 *
 * ```ts
 * @Roles('admin', 'manager')
 * @Get('protected')
 * findProtected() {}
 * ```
 */
export const Roles = (...roles: string[]) => SetMetadata('roles', roles);