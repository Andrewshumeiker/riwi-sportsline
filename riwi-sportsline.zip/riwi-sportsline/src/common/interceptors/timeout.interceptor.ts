import {
  CallHandler,
  ExecutionContext,
  Injectable,
  NestInterceptor,
} from '@nestjs/common';
import { Observable } from 'rxjs';
import { tap } from 'rxjs/operators';

/**
 * An interceptor that measures how long each request takes to complete.
 * The result is logged to the console.  This is useful during
 * development and can help identify slow endpoints.
 */
@Injectable()
export class TimeoutInterceptor implements NestInterceptor {
  intercept(context: ExecutionContext, next: CallHandler): Observable<any> {
    const now = Date.now();
    return next.handle().pipe(
      tap(() => {
        const diff = Date.now() - now;
        const req = context.switchToHttp().getRequest();
        console.log(
          `${req.method} ${req.url} completed in ${diff}ms`,
        );
      }),
    );
  }
}