import { IsString, IsNotEmpty, IsOptional, IsArray, ArrayUnique } from 'class-validator';

/**
 * DTO for creating a new role.  Roles require a unique name and can
 * include a description and a list of permission IDs to be
 * associated upon creation.
 */
export class CreateRoleDto {
  @IsString()
  @IsNotEmpty()
  name!: string;

  @IsOptional()
  @IsString()
  description?: string;

  @IsOptional()
  @IsArray()
  @ArrayUnique()
  permissionIds?: string[];
}