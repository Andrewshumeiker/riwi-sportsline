import {
  Controller,
  Post,
  Body,
  UseGuards,
  Request,
  Get,
} from '@nestjs/common';
import { AuthService } from './auth.service';
import { CreateUserDto } from '../users/dto/create-user.dto';
import { LoginDto } from './dto/login.dto';
import { LocalAuthGuard } from './guards/local-auth.guard';
import { JwtAuthGuard } from './guards/jwt-auth.guard';
import { AuthGuard } from '@nestjs/passport';

/**
 * Controller responsible for authentication endpoints including
 * registration, login, refresh, and OAuth.  Guards are used to
 * delegate validation to Passport strategies.
 */
@Controller('auth')
export class AuthController {
  constructor(private readonly authService: AuthService) {}

  /**
   * Register a new user.  Returns access and refresh tokens on
   * success.  Roles and permissions can be provided via the DTO.
   */
  @Post('register')
  register(@Body() dto: CreateUserDto) {
    return this.authService.register(dto);
  }

  /**
   * Log in with email and password.  Uses LocalAuthGuard to validate
   * credentials.  Returns access and refresh tokens on success.
   */
  @UseGuards(LocalAuthGuard)
  @Post('login')
  login(@Request() req: any) {
    return this.authService.login(req.user);
  }

  /**
   * Refresh an access token using a valid refresh token.  Returns a
   * new pair of access and refresh tokens.  If the provided token is
   * invalid or expired an UnauthorizedException is thrown.
   */
  @Post('refresh')
  refresh(@Body('refreshToken') refreshToken: string) {
    return this.authService.refresh(refreshToken);
  }

  /**
   * Retrieve the authenticated user's profile.  Requires a valid
   * access token.
   */
  @UseGuards(JwtAuthGuard)
  @Get('profile')
  profile(@Request() req: any) {
    return req.user;
  }

  /**
   * Initiate Google OAuth login.  Redirects the user to Google's
   * authentication page.  The GoogleStrategy defines the scope and
   * callback URL.  This route does not return a JSON response.
   */
  @Get('google')
  @UseGuards(AuthGuard('google'))
  async googleAuth() {
    // Passport handles the redirect automatically
  }

  /**
   * Handle the Google OAuth callback.  On success the user is
   * authenticated and the request.user is populated.  The user is
   * then logged in and tokens are returned.
   */
  @Get('google/callback')
  @UseGuards(AuthGuard('google'))
  async googleAuthRedirect(@Request() req: any) {
    return this.authService.login(req.user);
  }
}