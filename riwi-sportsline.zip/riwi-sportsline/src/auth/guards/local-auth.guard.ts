import { Injectable } from '@nestjs/common';
import { AuthGuard } from '@nestjs/passport';

/**
 * LocalAuthGuard validates user credentials using the local strategy.
 * It populates req.user with the authenticated user if successful.
 */
@Injectable()
export class LocalAuthGuard extends AuthGuard('local') {}