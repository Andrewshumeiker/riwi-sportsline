import { IsEmail, IsString, MinLength } from 'class-validator';

/**
 * DTO for user login.  Expects an email and password pair.  The
 * LocalStrategy will validate these credentials.
 */
export class LoginDto {
  @IsEmail()
  email!: string;

  @IsString()
  @MinLength(6)
  password!: string;
}