import { Injectable, UnauthorizedException } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { ConfigService } from '@nestjs/config';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import * as bcrypt from 'bcrypt';
import { v4 as uuidv4 } from 'uuid';
import { UsersService } from '../users/users.service';
import { CreateUserDto } from '../users/dto/create-user.dto';
import { User } from '../users/entities/user.entity';
import { RefreshToken } from './entities/refresh-token.entity';

/**
 * AuthService encapsulates the authentication and token lifecycle.  It
 * validates user credentials, issues access and refresh tokens, and
 * handles refreshing tokens.  Refresh tokens are stored in a
 * repository to support revocation and expiration.
 */
@Injectable()
export class AuthService {
  constructor(
    private readonly usersService: UsersService,
    private readonly jwtService: JwtService,
    private readonly configService: ConfigService,
    @InjectRepository(RefreshToken)
    private readonly refreshRepository: Repository<RefreshToken>,
  ) {}

  /**
   * Validate a user's credentials.  Returns the user if valid or null
   * otherwise.  Passwords are compared using bcrypt.
   */
  async validateUser(email: string, password: string): Promise<User | null> {
    const user = await this.usersService.findByEmail(email);
    if (!user) return null;
    const isValid = await bcrypt.compare(password, user.password);
    return isValid ? user : null;
  }

  /**
   * Login a user by generating a signed access token and a refresh
   * token.  The refresh token is persisted so that it can later be
   * validated and revoked.
   */
  async login(user: User) {
    const roles = user.roles?.map((role) => role.name) || [];
    // Combine direct permissions and those inherited from roles
    const rolePermissions = user.roles
      ?.flatMap((role) => role.permissions.map((p) => p.name))
      .filter((perm, index, arr) => arr.indexOf(perm) === index) || [];
    const userPermissions = user.permissions?.map((p) => p.name) || [];
    const permissions = Array.from(new Set([...rolePermissions, ...userPermissions]));
    const payload = { sub: user.id, roles, permissions };
    const accessToken = await this.jwtService.signAsync(payload, {
      secret: this.configService.get<string>('jwt.secret'),
      expiresIn: this.configService.get<string>('jwt.expiration'),
    });
    const refreshToken = uuidv4();
    const expiresAt = new Date(
      Date.now() + parseInt(this.configService.get<string>('jwt.refreshExpiration'), 10) * 1000,
    );
    const entity = this.refreshRepository.create({ token: refreshToken, user, expiresAt });
    await this.refreshRepository.save(entity);
    return { accessToken, refreshToken };
  }

  /**
   * Register a new user.  Delegates to the UsersService which
   * handles hashing and persistence.  Immediately logs in the new
   * user to return tokens.
   */
  async register(dto: CreateUserDto) {
    const user = await this.usersService.create(dto);
    return this.login(user);
  }

  /**
   * Generate a new access and refresh token from an existing refresh
   * token.  The supplied token must exist in the repository and must
   * not have expired.  Once used it is revoked and replaced with a
   * fresh token.
   */
  async refresh(oldToken: string) {
    const tokenEntity = await this.refreshRepository.findOne({
      where: { token: oldToken },
      relations: ['user'],
    });
    if (!tokenEntity || tokenEntity.expiresAt < new Date()) {
      throw new UnauthorizedException('Invalid refresh token');
    }
    // Remove the used refresh token to prevent reuse
    await this.refreshRepository.remove(tokenEntity);
    return this.login(tokenEntity.user);
  }
}