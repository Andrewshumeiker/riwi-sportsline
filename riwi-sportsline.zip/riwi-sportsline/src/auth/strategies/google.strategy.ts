import { Injectable } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { PassportStrategy } from '@nestjs/passport';
import { Strategy as OAuth2Strategy, VerifyCallback } from 'passport-oauth2';
import { UsersService } from '../../users/users.service';

/**
 * A basic OAuth2 strategy configured for Google.  This example
 * demonstrates how you would wire up an OAuth2 strategy with
 * NestJS.  In a full implementation you would use
 * `passport-google-oauth20` for Google specific profile fields.
 */
@Injectable()
export class GoogleStrategy extends PassportStrategy(OAuth2Strategy, 'google') {
  constructor(
    private readonly configService: ConfigService,
    private readonly usersService: UsersService,
  ) {
    super({
      authorizationURL: 'https://accounts.google.com/o/oauth2/v2/auth',
      tokenURL: 'https://oauth2.googleapis.com/token',
      clientID: configService.get<string>('oauth.google.clientId'),
      clientSecret: configService.get<string>('oauth.google.clientSecret'),
      callbackURL: configService.get<string>('oauth.google.callbackUrl'),
      scope: ['email', 'profile'],
    });
  }

  // The validate method is called after Google returns the user profile.
  async validate(
    accessToken: string,
    refreshToken: string,
    profile: any,
    done: VerifyCallback,
  ): Promise<any> {
    // Extract user information from the profile and find or create a user
    const email = profile?.email || (profile.emails && profile.emails[0].value);
    let user = await this.usersService.findByEmail(email);
    if (!user) {
      // Create a user with a random password since OAuth users sign in via Google
      user = await this.usersService.create({
        name: profile.displayName || email,
        email,
        password: 'oauth2',
        roleIds: [],
        permissionIds: [],
      });
    }
    done(null, user);
  }
}