import { Injectable } from '@nestjs/common';
import { PassportStrategy } from '@nestjs/passport';
import { ExtractJwt, Strategy } from 'passport-jwt';
import { ConfigService } from '@nestjs/config';

/**
 * Strategy to validate JWT access tokens.  It uses the secret and
 * options provided in the ConfigService.  When a token is valid it
 * returns its payload as the request.user object.
 */
@Injectable()
export class JwtStrategy extends PassportStrategy(Strategy) {
  constructor(private readonly configService: ConfigService) {
    super({
      jwtFromRequest: ExtractJwt.fromAuthHeaderAsBearerToken(),
      ignoreExpiration: false,
      secretOrKey: configService.get<string>('jwt.secret'),
    });
  }

  async validate(payload: any) {
    // The payload contains whatever fields were signed in AuthService
    return { userId: payload.sub, roles: payload.roles, permissions: payload.permissions };
  }
}