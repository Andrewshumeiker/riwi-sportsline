import { Entity, PrimaryGeneratedColumn, Column, ManyToOne } from 'typeorm';
import { User } from '../../users/entities/user.entity';

/**
 * Refresh tokens allow clients to obtain new access tokens without
 * re‑authenticating.  They are stored in the database to support
 * revocation and expiration.  Tokens are stored hashed in a real
 * implementation; this example stores them in plain text for
 * simplicity.
 */
@Entity()
export class RefreshToken {
  @PrimaryGeneratedColumn('uuid')
  id!: string;

  @Column()
  token!: string;

  @Column({ type: 'timestamp' })
  expiresAt!: Date;

  @ManyToOne(() => User, (user) => user.id, { eager: true })
  user!: User;
}