import { Module } from '@nestjs/common';

/**
 * ApiKeyModule is a placeholder for future API key management
 * features.  In a real application this module would expose an API
 * to create, revoke and list API keys as well as persist them in
 * the database.  For now the valid keys are loaded from environment
 * variables via ConfigModule.
 */
@Module({})
export class ApiKeyModule {}