#!/bin/sh

# This file is used by Husky to run hooks. It ensures that commands
# specified in hook scripts are executed within the context of the
# repository. Without this file Husky will not function correctly.

if [ -z "$husky_skip_init" ]; then
  debug () {
    [ "$HUSKY_DEBUG" = "1" ] && echo "husky:debug $*"
  }

  readonly hook_name="$(basename "$0")"
  debug "starting $hook_name..."
  if [ -z "$skip_githooks" ]; then
    [ -f ~/.huskyrc ] && . ~/.huskyrc
    hook_filepath="$0"
    script_dir="$(dirname "$hook_filepath")/.."
    debug "from $hook_filepath, reading $script_dir/.huskyrc"
    [ -f "$script_dir/.huskyrc" ] && . "$script_dir/.huskyrc"
  fi
fi