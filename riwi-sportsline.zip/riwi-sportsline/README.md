# Riwi SportsLine Backend

This project represents a migration of an existing e‑commerce backend from an Express codebase to **NestJS**.  It leverages **TypeORM** for database persistence, **Passport** for authentication/authorization, and includes examples of middleware, filters, guards, interceptors, DTOs, and testing.

The goal of this migration is to adopt a more maintainable and scalable architecture.  While this repository is not feature complete, it provides a solid foundation demonstrating how to organize modules, entities, and authentication strategies in NestJS.

## Features

- Modular architecture with separate modules for users, products, clients, orders, roles, permissions, and authentication.
- TypeORM entities representing tables in a PostgreSQL database and relationships between them.
- DTOs using `class-validator` and `class-transformer` to validate incoming requests.
- Global configuration via `@nestjs/config` with validation of environment variables.
- Middleware, guards, interceptors, and exception filters to centralize cross‑cutting concerns.
- Authentication with JWT access and refresh tokens, roles and permissions enforced through guards, x‑API‑key support, and an example OAuth2 strategy.
- Swagger documentation generated automatically from decorators.
- ESLint, Prettier, Husky, and lint‑staged configured to enforce code quality.
- A sample SonarQube configuration to enable static analysis.

## Getting Started

1. **Install dependencies**

   ```bash
   npm install
   ```

   Note: The package names are included for reference; they may require network access during installation.

2. **Create a `.env` file** from `.env.example` and provide real values for your database, JWT secrets, API keys, and OAuth credentials.

3. **Run the development server**

   ```bash
   npm run start:dev
   ```

4. **Open Swagger UI** at `http://localhost:3000/api` to explore and test the API endpoints.

5. **Run tests** (optional)

   ```bash
   npm test
   ```

## Project Structure

```
riwi-sportsline/
├── src/
│   ├── app.module.ts       # Root module, imports feature modules
│   ├── main.ts            # Entry point, sets up Nest app and Swagger
│   ├── config/            # Configuration loaders and validation
│   ├── common/            # Guards, filters, interceptors, pipes
│   ├── middleware/        # Global middleware implementations
│   ├── entities/          # Shared entities
│   ├── users/             # Users module (controller, service, entity, dto)
│   ├── products/          # Products module
│   ├── clients/           # Clients module
│   ├── orders/            # Orders module
│   ├── roles/             # Roles module
│   ├── permissions/       # Permissions module
│   ├── auth/              # Authentication module and strategies
│   └── ...
├── test/                  # Example tests (placeholders)
├── .husky/                # Husky hooks for pre‑commit
├── .env.example           # Example environment variables
├── .eslintrc.js           # ESLint configuration
├── .prettierrc            # Prettier configuration
├── sonar-project.properties # SonarQube configuration
└── README.md              # This file
```

## Notes

* The code includes comments throughout explaining how each part works and why certain patterns are used.  Comments are written in English.
* Database entities define basic relationships but do not cover every field your original Express models may have had.  They serve as examples to get you started.
* OAuth2 integration uses placeholders for client credentials.  Replace these values with real credentials from your OAuth provider (e.g. Google).
* The API key guard reads a list of valid keys from environment variables.  In a real application you would persist keys in a database and provide an administration interface to issue and revoke them.
